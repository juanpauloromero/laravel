
<?php $__env->startSection('title', 'Ajouter un Repas'); ?>
<?php $__env->startSection('content'); ?>
   
       
            <h1>Ajouter un Repas</h1>
           

            <div class="container form-group">
                        <div class="mb-3">
                            <form action="<?php echo e(route('admin.dishes.store', 'upload-image')); ?>" method="post"
                                enctype="multipart/form-data" id="upload-image">
                                <?php echo csrf_field(); ?>
                                </div>
                                <div class="mb-3">
                                    <label for="name" class="form-label"> Nom du plat</label>
                                    <input id="name" name="dish_name" type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mb-3">
                                    <label for="description" class="form-label"> Description: ingredients</label>
                                    <textarea id="description" name="dish_description" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"></textarea>
                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="mb-3">
                                    <label>Seleccioner une image:</label>
                                    <input type="file" name="image" id="image"
                                        class="form-control  <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <?php $__errorArgs = ['Image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                   <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="is_active" class="form-label">Disponibilté du plat</label>
                                <select id="is_active" name="is_active" type="text" class="form-select">
                                    <option value="1" selected>Disponible</option>
                                    <option value="0" selected>Non-disponible</option>
                            </div>
                            <div class="mb-3">

                                <input type="submit" value="sauvegarder" class=" buttonAjout"> 
                                </div>
                               
                                <div class="mb-3">

                                <a href="<?php echo e(route('admin.dishes.index')); ?>" class="buttonRetour" role="button" data-bs-toggle="button">Retour</a>
                                
                                </div>
                                <div class=" mb-3">
                                  <div class="card">
                                    <div class="card-body">
                                     <img id="preview-image-before-upload" alt="preview image" >
                                </div>
                            </div>
                         </div>

       
                </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jpri1\Desktop\420-706-FE PROJET INTÉGRATEUR\grille-o-presto\resources\views/admin/dishes/create.blade.php ENDPATH**/ ?>