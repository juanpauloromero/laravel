<html>
<?php echo $__env->make('layouts.admin.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<div class="navbar navbar-default navbar-fixed-top" role="navigation">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="#"> <img src="<?php echo e(asset('image/logo.svg')); ?>" alt="Logo Grille O Presto" class="logo"></a>
        </div>
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
                <li><a href="" target="_blank">Deconnexion</a></li>
            </ul>
            <ul class="nav navbar-nav">
                <li class="active"><a href="#">Accueil</a></li>
                <li>
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Gestion Admin <b class="caret"></b></a>
                    <ul class="dropdown-menu multi-level">
                        <li><a href="<?php echo e(route('admin.admin.create')); ?>">Add Admin</a></li>
                        <li><a href="<?php echo e(route('admin.admin.index')); ?>">Liste Admin</a></li>
                        </ul>
                        </li>   
                        <li>
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Gestion clients <b class="caret"></b></a>
                    <ul class="dropdown-menu multi-level">
                        <li><a href="<?php echo e(route('admin.users.index')); ?>">Liste Clients</a></li>
                       </ul>
                        </li> 
                        <li>
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Gestion Menu <b class="caret"></b></a>
                    <ul class="dropdown-menu multi-level">
                        <li><a href="<?php echo e(route('admin.menus.create')); ?>">Add Menu</a></li>
                        <li><a href="<?php echo e(route('admin.menus.index')); ?>">Liste Menu</a></li>
                        </ul>
                        </li>  
                        <li>
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">Gestion Plats <b class="caret"></b></a>
                    <ul class="dropdown-menu multi-level">
                        <li><a href="<?php echo e(route('admin.dishes.create')); ?>">Add
                        Plats</a></li>
                        <li><a href="<?php echo e(route('admin.dishes.index')); ?>">Liste
                        de Plats</a></li>
                        </ul>
                        </li>   
                         
                        <li class="active"><a href="<?php echo e(route('admin.orders.index')); ?>">Commandes</a></li> 
                        </li>   
                        </ul>
        </div><!--/.nav-collapse -->
    </div>
</div>

<div>
    <?php echo $__env->yieldContent('content'); ?>
</div>


</html>
<?php /**PATH C:\Users\jpri1\Desktop\420-706-FE PROJET INTÉGRATEUR\grille-o-presto\resources\views/layouts/admin/app.blade.php ENDPATH**/ ?>