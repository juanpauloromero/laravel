<?php $__env->startSection('content'); ?>

    <h1>Client</h1>
    <?php if(session('succes')): ?>
        <?php echo e(session('succes')); ?>

    <?php endif; ?>
        <table class="table">
            <thead>
                <th>Prenom</th>
                <th>Nom</th>
                <th>Adresse</th>
                <th>Email</th>
                <th>Telephone</th>
            </thead>
            
             <tbody>
    
                    <tr>
                        <td><?php echo e(Auth::user()->user_firstname); ?></td>
                        <td><?php echo e(Auth::user()->user_lastname); ?></td>
                        <td><?php echo e(Auth::user()->user_adresse); ?></td>
                        <td><?php echo e(Auth::user()->email); ?></td>
                        <td><?php echo e(Auth::user()->user_phone); ?></td>
                        <td><a href="<?php echo e(route('home.fidelities.edit', Auth::user())); ?>">Modifier</a>
            </tbody>
        </table>
            <table class="table">
                <thead>
                    <th>Adresse Livraison</th>
                    <th>Prix</th>
                    <th>Plat</th>
                </thead>
                <tbody>
                    
                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       
                        <tr>
                            <td> <?php echo e($order->order_adresse); ?> </td>
                            <td> <?php echo e($order->order_total); ?> </td>
                            <?php $__currentLoopData = $order->dishes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td> <?php echo e($dish->dish_name); ?> </td>
                        </td>
                        </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </tbody>
            </table>
       
            
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jpri1\Desktop\420-706-FE PROJET INTÉGRATEUR\grille-o-presto\resources\views/home/fidelities/index.blade.php ENDPATH**/ ?>