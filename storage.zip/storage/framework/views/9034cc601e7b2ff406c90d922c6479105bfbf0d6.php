

<?php $__env->startSection('content'); ?>
<html>
<body>
  <div class="container">
    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
		    <div class="alert alert-danger"><?php echo e($message); ?></div>
			<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <div class="title">Connexion</div>
    <div class="content">
      <form action="<?php echo e(route('login')); ?>" method="post">
       <?php echo csrf_field(); ?>
        <div class="user-details">
         
          <div class="input-box">
            <label for="email" class="details">Courriel</label>
            <input id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" placeholder="Entrez votre courriel" required>
          </div>
          

          <div class="input-box">
            <label for="password" class="details">Mot de passe</label>
            <input id="password" name="password" type="password" placeholder="Entrez votre mot de passe" required>
          </div>
        </div>
      
        </div>
        <div class="button">
          <input type="submit" value="Connexion">
        </div>
      </form>
    </div>
  </div>

</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jpri1\Desktop\420-706-FE PROJET INTÉGRATEUR\grille-o-presto\resources\views/session/create.blade.php ENDPATH**/ ?>