

<?php $__env->startSection('title', 'Modifier un Repas'); ?>

<?php $__env->startSection('content'); ?>

  

    <body>
        <div>
            <h1> Modifier un plats <?php echo e($dish->name); ?></h1>
            <div class="row">
                <br>
            </div>

            <div class="container ">
                <div class="row">
                    <div class="col-md-4">
                        <h2>Bonjour</h2>
                        <div class="card">
                            <div class="card-body">
                                <div class="col-md-12 mb-2">
                                    <img id="preview-image-before-upload" alt="preview image" style="max-height: 250px;">
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="col-md-8">

                        <h2 style="text-align:left;"> Information du Plats</h2>
                        <hr>

                        <div class="row">
                            <form action="<?php echo e(route('admin.dishes.update', $dish->id, 'upload-image')); ?>" method="POST"
                                enctype="multipart/form-data" id="upload-image">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <div class="col-md-6">
                                    <label for="name" class="form-label">Nom du repas</label>
                                    <input id="name" name="dish_name" type="text" value="<?php echo e($dish->dish_name); ?>"
                                        class="form-control">
                                </div>

                                <div class="col-md-12">
                                    <label for="description" class="form-label">Description</label>
                                    <textarea id="description" name="dish_description" class=form-control> <?php echo e($dish->dish_description); ?></textarea>
                                </div>

                                <div class="col-md-6">
                                    <label>Select Image File:</label>
                                    <input type="file" name="image" id="image" value="<?php echo e($dish->image); ?>"
                                        class="form-control
                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
                    <?php $__errorArgs = ['Image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
<span class="invalid-feedback
                                        role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-6">
                                <label for="is_active" class="form-label">Disponibilité du plats</label>
                                <select id="is_active" name="is_active" type="text" class="form-select">
                                    <option value="1" <?php if($dish->is_active): ?> selected <?php endif; ?>>Disponible
                                    </option>
                                    <option value="0" <?php if(!$dish->is_active): ?> selected <?php endif; ?>>
                                        Non-Disponible</option>
                                </select>
                            </div>

                            <input type="submit" value="sauvegarder" class="btn btn-primary">
                            <a href="<?php echo e(route('admin.dishes.index')); ?>" class="btn btn-secondary">Retour</a>
                        </form>
                    </div>
                </div>

            </div>
</body>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jpri1\Desktop\420-706-FE PROJET INTÉGRATEUR\grille-o-presto\resources\views/admin/dishes/edit.blade.php ENDPATH**/ ?>