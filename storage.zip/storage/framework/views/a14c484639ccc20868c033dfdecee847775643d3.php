

<?php $__env->startSection('title', 'Repas'); ?>

<?php $__env->startSection('content'); ?>
    <h1>Repas</h1>
    <?php if(session('succes')): ?>
        <?php echo e(session('succes')); ?>

    <?php endif; ?>
    <?php if($dishes->count() > 0): ?>
        <table class="table">
            <thead>
                <th>Nom</th>
                <th>Description</th>
                <th>Disponibilité</th>
                <th>Modifier</th>
                <th>Supprimer</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $dishes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($dish->dish_name); ?></td>
                        <td><?php echo e($dish->dish_description); ?></td>

                        <td>
                            <?php if($dish->is_active): ?>
                                Disponible
                            <?php else: ?>
                                Non-Disponible
                            <?php endif; ?>
                        </td>
                        <td>
                        <a href="<?php echo e(route('admin.dishes.edit', $dish->id)); ?>" class="bi bi-pencil-square" role= "button">
                          <svg xmlns="http://www.w3.org/2000/svg" width="30" height="10" fill="currentColor"  viewBox="0 0 16 16">
                          <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
                          <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z"/>
                         </svg>
                         </a>
                        <td>
                            <form method="POST" action="<?php echo e(route('admin.dishes.destroy', $dish->id)); ?>" >
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" value="Supprimer" class="bi bi-trash3-fill" onclick="return myFunction();">
                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" fill="currentColor"  viewBox="0 0 16 16">
                              <path d="M11 1.5v1h3.5a.5.5 0 0 1 0 1h-.538l-.853 10.66A2 2 0 0 1 11.115 16h-6.23a2 2 0 0 1-1.994-1.84L2.038 3.5H1.5a.5.5 0 0 1 0-1H5v-1A1.5 1.5 0 0 1 6.5 0h3A1.5 1.5 0 0 1 11 1.5Zm-5 0v1h4v-1a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5ZM4.5 5.029l.5 8.5a.5.5 0 1 0 .998-.06l-.5-8.5a.5.5 0 1 0-.998.06Zm6.53-.528a.5.5 0 0 0-.528.47l-.5 8.5a.5.5 0 0 0 .998.058l.5-8.5a.5.5 0 0 0-.47-.528ZM8 4.5a.5.5 0 0 0-.5.5v8.5a.5.5 0 0 0 1 0V5a.5.5 0 0 0-.5-.5Z"/>
                              </svg>
                              </button>
                              </form>
                        </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>Aucune repas à afficher pour le moment.</p>
    <?php endif; ?>
    <a href="<?php echo e(route('admin.dishes.create')); ?>">Ajouter un repas</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jpri1\Desktop\420-706-FE PROJET INTÉGRATEUR\grille-o-presto\resources\views/admin/dishes/index.blade.php ENDPATH**/ ?>