

<?php $__env->startSection('title', 'Liste de Commandes Grill-o-Presto'); ?>

<?php $__env->startSection('content'); ?>

<h1>COMMANDES GRILLE-O-PRESTO</h1>

<?php if(session('succes')): ?>
        <?php echo e(session('succes')); ?>

    <?php endif; ?>
      
        <table class="container table">
            <thead>
                <th>Nom Client</th>
                <th>Email Client</th>
                <th>Adresse Livraison</th>
                <th>Description</th>
                 <th>Supprimer</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   
                    <tr>
                        <td><?php echo e($order->order_firstname . $order->order_lastname); ?></td>
                        <td> <?php echo e($order->order_email); ?> </td>
                        <td> <?php echo e($order->order_adresse); ?> </td>
                        <?php $__currentLoopData = $order->dishes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dish): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td> <?php echo e($dish->dish_name); ?> </td>
                        
                        <td>
                            <form method="POST"action="<?php echo e(route('admin.orders.destroy', $order->id)); ?>" class="mb-3">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" value="Supprimer" class="bi bi-trash3-fill" onclick="return myFunction();">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor"  viewBox="0 0 16 16">
                              <path d="M11 1.5v1h3.5a.5.5 0 0 1 0 1h-.538l-.853 10.66A2 2 0 0 1 11.115 16h-6.23a2 2 0 0 1-1.994-1.84L2.038 3.5H1.5a.5.5 0 0 1 0-1H5v-1A1.5 1.5 0 0 1 6.5 0h3A1.5 1.5 0 0 1 11 1.5Zm-5 0v1h4v-1a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5ZM4.5 5.029l.5 8.5a.5.5 0 1 0 .998-.06l-.5-8.5a.5.5 0 1 0-.998.06Zm6.53-.528a.5.5 0 0 0-.528.47l-.5 8.5a.5.5 0 0 0 .998.058l.5-8.5a.5.5 0 0 0-.47-.528ZM8 4.5a.5.5 0 0 0-.5.5v8.5a.5.5 0 0 0 1 0V5a.5.5 0 0 0-.5-.5Z"/>
                              </svg>
                              </button>
                              </form>
                        </td>
                      
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
  
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\jpri1\Desktop\420-706-FE PROJET INTÉGRATEUR\grille-o-presto\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>